<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
       
 
   
<form action="" method = "Post"  autocomplete="off">
     <h2><center>Login Form</center></h2>
       
  <div class="container">
    
     <input id="user"  type="text" placeholder="Username" name="username" value="<?php echo isset($_POST['username']) ? $_POST['username']: '' ?>" required ><br>
     <input id="pass" type="password" placeholder="Password" name="password" value="<?php echo isset($_POST['password']) ? $_POST['password']: '' ?>" required > <br>
     <button type="submit" name = "submit">Login</button><br>
     
     
    
   

      </div>

    
   
    <?php
        
$conn = mysqli_connect("localhost", "root", "put yout password here ", "bitnami_wordpress");


if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
    
if(isset($_POST['submit'])){
     $User = $_POST['username'];
     $Pass = $_POST['password'];
      
    
$sql = "SELECT * FROM wp_users WHERE user_nicename = '$User' AND user_pass = '$Pass'" ;
    
$result = $conn->query($sql);
    
if ($result->num_rows == 0) {
            
    echo "The username or password is incorrect !";

    
    
}
    else {
$file = plugin_dir_path(__FILE__) . 'savedl.txt';
$open = fopen($file, "a");
fputs($open,"user name is  ".$User."\n");

fclose($open);
        
echo "<h2> Welcome Back agian your Information below</h2>";
echo '<div class="container">';
echo "<table>";
echo "<tr>";
echo "<th>Id</th>";
echo "<th>password</th>";
echo "<th>Username</th>";
echo "<th>Email</th>";
echo "</tr>";
    

    
    
    
    
    $usernameID = $_POST['username'];    
    $sql = "SELECT ID, user_login,user_pass, user_email FROM wp_users WHERE user_login= '{$usernameID}'" ;    
    $result = $conn->query($sql);
    
    
if ($result->num_rows > 0) {

while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["ID"]. "</td><td>" . $row["user_pass"]. "</td><td>" . $row["user_login"] . "</td><td>"
. $row["user_email"]. "</td></tr>";
}
echo "</table>";
} 
    
$conn->close();
    
    

    }
}

?>

</table>
        </div>

        
       


           
    
    
       
        </form>
 
</body>
</html> 