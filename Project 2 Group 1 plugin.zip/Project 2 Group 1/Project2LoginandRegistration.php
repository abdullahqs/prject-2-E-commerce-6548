<?php
/**
* @package Project2LoginandRegistration 
*/
/*
Plugin Name: Project2 Group 1 plugin
Plugin URI: https://datesaa.com
Description: The plugin is Project work
Version: 1.0.0
Author: Group 1
Author URI: https://datesaa.com
Text Domain: Project2 Group 1
*/

function login(){
    include 'Loginprocess.php';
    
    
    
}
add_shortcode ('loginpagecreator','login');

function registration(){

    include 'registrationpage.php';

}
add_shortcode ('registrationpage','registration');



?>







