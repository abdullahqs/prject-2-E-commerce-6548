<?php
/*
Plugin Name: Contact Form Plugin
Plugin URI: https://www.goodfit.ml
Description: WordPress Contact Form
Version: 0.0.1
Author: Keith Casscells-Hamby
Author URI: https://www.goodfit.ml
*/

function contact_form_create_table(){
        global $wpdb;
        global $table_version;

        $table_name = $wpdb->prefix."contactus";
        $slider_ver = get_option("table_version");

        $sql= "CREATE TABLE `$table_name`(
                id INT(6) UNSIGNED NOT NULL AUTO_INCREMENT,
                name VARCHAR(30) NOT NULL,
                email VARCHAR(30) NOT NULL,
                sub VARCHAR(50) NOT NULL,
                msg VARCHAR(500) NOT NULL,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
                );";

        require_once(ABSPATH.'wp-admin/includes/upgrade.php');
        dbDelta($sql);

        update_option("table_version", $table_version);
}

register_activation_hook(__FILE__, 'contact_form_create_table');

function remove_contact_form_data() {
        global $wpdb;
        $sql = 'DROP TABLE wp_contactus;';

        $wpdb->query($sql);
}

register_deactivation_hook( __FILE__, 'remove_contact_form_data' );

function deliver_mail() {

        // if the submit button is clicked, send the email
        if ( isset( $_POST['cf-submitted'] ) ) {

                // sanitize form values
                $name    = $_POST["cf-name"];
                $email   = $_POST["cf-email"];
                $subject = $_POST["cf-subject"];
                $message = esc_textarea( $_POST["cf-message"] );

                // get the blog administrator's email address
                $to = get_option( 'admin_email' );

                $headers = "From: $name <$email>" . "\r\n";

                // If email has been process for sending, display a success message
                if ( wp_mail( $to, $subject, $message, $headers ) ) {
                        echo '<div>';
                        echo '<p>Thanks for contacting me, expect a response soon.</p>';
                        echo '</div>';
                }
                global $wpdb;

                $table_contactus = $wpdb->prefix."contactus";

                $sql = "INSERT INTO $table_contactus
                        (name, email, sub, msg, timestamp)
                        VALUES
                        ('$name', '$email', '$subject', '$message', DEFAULT)";
                //dbDelta($sql);
                $wpdb->query($sql);
        }
}


function html_form_code() {
	echo '<form action="' . esc_url( $_SERVER['REQUEST_URI'] ) . '" method="post">';
	echo '<p>';
	echo 'Your Name (required) <br/>';
	echo '<input type="text" name="cf-name" value="' . ( isset( $_POST["cf-name"] ) ? esc_attr( $_POST["cf-name"] ) : '' ) . '" size="40" />';
	echo '</p>';
	echo '<p>';
	echo 'Your Email (required) <br/>';
	echo '<input type="email" name="cf-email" value="' . ( isset( $_POST["cf-email"] ) ? esc_attr( $_POST["cf-email"] ) : '' ) . '" size="40" />';
	echo '</p>';
	echo '<p>';
	echo 'Subject (required) <br/>';
	echo '<input type="text" name="cf-subject" value="' . ( isset( $_POST["cf-subject"] ) ? esc_attr( $_POST["cf-subject"] ) : '' ) . '" size="40" />';
	echo '</p>';
	echo '<p>';
	echo 'Your Message (required) <br/>';
	echo '<textarea rows="10" cols="35" name="cf-message">' . ( isset( $_POST["cf-message"] ) ? esc_attr( $_POST["cf-message"] ) : '' ) . '</textarea>';
	echo '</p>';
	echo '<p><input type="submit" name="cf-submitted" value="Send"></p>';
	echo '</form>';
}

function cf_shortcode() {
	ob_start();
	deliver_mail();
	html_form_code();

	return ob_get_clean();
}

add_shortcode( 'comment_form', 'cf_shortcode' );

?>