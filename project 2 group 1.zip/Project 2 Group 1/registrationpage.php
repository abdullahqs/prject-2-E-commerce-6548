<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>

<form action="" method="post">
    <h2><center>New User Account</center></h2>
  <div class="container">
    
    <input type="text" placeholder=Username name="username" required>
      <br>
   
    <input type="password" placeholder="Password" name="password" required><br>
    <input type="email" placeholder="Email" name="email" required><br>
      

    
    
    
      
    <button type="submit" name="submit">Create Account</button><br>  
  </div>
      <?php
        
$conn = mysqli_connect("localhost", "root", "put your password here ", "bitnami_wordpress");
// Check connection

if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
    
     
if(isset($_POST['submit'])){
    $User = $_POST['username'];
    $UserPassword = $_POST['password'];
    $Email = $_POST['email'];
    $Date = date("Y-m-d H:i:s");
    $sql = "INSERT INTO wp_users (ID, user_login, user_pass, user_nicename, user_email, user_url, user_registered, user_activation_key, user_status, display_name) VALUES (NULL, '$User', '$UserPassword', '$User', '$Email', '', '$Date', '', '0', '');
    " ;

if ($conn->query($sql) === TRUE) {
    echo '<script type="text/javascript">';
echo ' alert("The user account has been created")';  //not showing an alert box.
echo '</script>';
    
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;

}


}
    
        
    


         


    

    

           
    ?>
    
</form>

</body>
</html>